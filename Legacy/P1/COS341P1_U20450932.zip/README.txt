Johannes Gerhardus Geyser, u20450932

To whom this may concern,

To adhere to the given rules about the practical I hav decided to use the following for NFA generation:
- RegularExpression.java
- NFA.java
- State.java

Files I have created for the practical are the following:
- DFA.java
- NFA_To_DFA.java // This does the conversion from NFA to DFA and the DFA minimization.



Both NFA.java and DFA.java use the State.java class for state representation.
">" represents epsilon "ε".

USAGE:

1. Input one line of regex in the Input.txt file.
2. Run the program with the below mentioned methods.
3. The output will be in the test.txt file.

Double click the jar file to run the program.

IF THIS DOES NOT WORK:

Open a terminal and navigate to the directory where the jar file is located.

Run: javac *.java
Run: java COS_341_P1

CREDIT FOR EXTERNAL LIBRARY FOR REGEX TO NFA CONVERSION:
Felipe Moreira Moura
- https://github.com/felipemoura/RegularExpression-to-NFA-to-DFA